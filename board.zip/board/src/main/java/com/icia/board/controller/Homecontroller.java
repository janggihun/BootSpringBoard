package com.icia.board.controller;

import com.icia.board.dto.MemberDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
@Slf4j
public class Homecontroller {



    @GetMapping("/")
    public String home(@ModelAttribute MemberDto memberDto, Model model){

        System.out.println("memberDtoid = " + memberDto.getM_id());
        System.out.println("memberDtopw = " + memberDto.getM_pw());
        System.out.println("model = " + model);

        return "index";
    }

}
