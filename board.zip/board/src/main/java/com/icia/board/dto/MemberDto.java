package com.icia.board.dto;


import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MemberDto {

    private String m_id;
    private String m_pw;


}
